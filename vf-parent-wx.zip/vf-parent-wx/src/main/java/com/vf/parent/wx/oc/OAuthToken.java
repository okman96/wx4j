package com.vf.parent.wx.oc;

import java.io.IOException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.client.ClientProtocolException;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.vf.parent.common.protocol.HttpUtil;

/**
 * 微信平台全局token凭证对象
 * 
 * <p>该类为单例</p>
 *
 * <p>
 * 通过<tt>Weixin</tt>产生一个请求对象，对应生成一个<tt>HttpClient</tt>，
 * 每次登陆产生一个<tt>OAuth</tt>用户连接,使用<tt>OAuthToken</tt>
 * 可以不用重复向微信平台发送登陆请求，在没有过期时间内，可继续请求。</p>
 *
 * @author zhangjingxuan
 */
public final class OAuthToken extends AbstractOC {

    /** Logger available */
    private final Log logger = LogFactory.getLog(getClass());
	
	/** 全局token **/
    private String access_token;
	/** 有效期    秒数 **/
	private int expires_in = 7200 - 60;
	/** 全局token创建时间    (秒) **/
	private long create_time;

	private volatile static OAuthToken instance = null;     
	
	public static OAuthToken getInstance() {  
        if (instance == null) {  
            synchronized (OAuthToken.class) {  
                if (instance == null) {  
                    instance = new OAuthToken();  
                }  
            }  
        }  
        return instance;  
    } 
	
	private OAuthToken() {
    }
    
    static {
    }
    
    /**
     * 判断凭证是否过期
     *
     * @auth zhangjingxuan
     * @return 过期返回 true,否则返回false
     * @throws IOException 
     * @throws ClientProtocolException 
     */
    private boolean isExprexpired() throws ClientProtocolException, IOException {
        long nowLong = System.currentTimeMillis() / 1000;
        boolean flag = nowLong >= (create_time + expires_in);
        return flag;
    }
    
    /**
     * 向微信发送请求重新获取token
     * 
     * <p>微信公众号正常情况下会返回:</p>
     * 
     * <code>{"access_token":"xxxxx","expires_in":7200}</code>
     *
     * @return 全局token
     * @throws IOException 
     * @throws ClientProtocolException 
     */
    @Override
    public String getAccess_token() throws Exception {
    	if (isExprexpired()) {
    	    StringBuilder requestUrl = new StringBuilder("https://api.weixin.qq.com/cgi-bin/token")
    	            .append("?grant_type=client_credential")
    	            .append("&appid=" + super.appid)
    	            .append("&secret=" + super.appsecret)
    	            .append("&grant_type=client_credential");
    	        JSONObject jsonObj = JSON.parseObject(HttpUtil.sendPost(requestUrl.toString()));
    	        if (jsonObj.containsKey("access_token")) {
    	            this.access_token = jsonObj.getString("access_token");        //设置全局token
    	            this.create_time = System.currentTimeMillis() / 1000;         //设置创建时间
    	        } else {
    	            if (logger.isDebugEnabled()) {
    	                logger.debug("access_token did not get to.  and response is:'" + jsonObj + "'");
    	            }
    	        }
		}
        return this.access_token;
    }
    
}
