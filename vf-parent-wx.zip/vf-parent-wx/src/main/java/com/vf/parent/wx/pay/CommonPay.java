package com.vf.parent.wx.pay;

import com.vf.parent.wx.common.Common;

public interface CommonPay extends Common {

    /**
     * 统一下单
     *
     * @auth zhangjingxuan
     * @since 2018年3月1日下午1:32:19
     * @param body              用户唯一标识
     * @param body              商品描述
     * @param total_fee         总金额（分）
     * @param spbill_create_ip  终端IP（如123.12.12.123）
     * @param out_trade_no      商户订单号（自生成）
     * @param nonce_str         随机字符串（不长于32位）
     * @return
     */
    String unifiedorder(String openid, String body, 
            String total_fee, 
            String spbill_create_ip, 
            String out_trade_no, String nonce_str, String wap_url, String wap_name);
    
    /**
     * 支付
     *
     * @auth zhangjingxuan
     * @since 2018年3月1日下午3:01:06
     * @param appid     微信程序唯一标识
     * @param prepayid  统一下单返回的凭证
     * @param apiid     商户密钥
     * @return
     */
    String pay(String appid, String prepayid, String apiid);
    
}
