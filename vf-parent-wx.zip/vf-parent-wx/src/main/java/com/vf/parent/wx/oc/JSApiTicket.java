package com.vf.parent.wx.oc;

import java.util.HashSet;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


public final class JSApiTicket {

    /** Logger available */
    private final Log logger = LogFactory.getLog(getClass());
    
    @Resource(name = "oAuthToken")
    public OAuthToken oAuthToken;
    
    private Set<JSApi> jsapiSet = null;
    
    private volatile static JSApiTicket instance = null;
    
    static {
    }
    
    public static JSApiTicket getInstance() {  
        if (instance == null) {  
            synchronized (JSApiTicket.class) {  
                if (instance == null) {  
                    instance = new JSApiTicket();  
                }  
            }  
        }  
        return instance;  
    }
    
    private JSApiTicket() {
        jsapiSet = new HashSet<JSApi>();
    }
    
    public JSApi getJSApi(String url) throws Exception {
        if (null == jsapiSet) {
            jsapiSet = new HashSet<JSApi>();
        }
        JSApi jsapi = new JSApi(oAuthToken.getAccess_token(), url);
        jsapiSet.add(jsapi);
        return jsapi;
    }
    
    public OAuthToken getOAuthToken() {
        return oAuthToken;
    }

    public void setOAuthToken(OAuthToken oAuthToken) {
        this.oAuthToken = oAuthToken;
    }
    
}
