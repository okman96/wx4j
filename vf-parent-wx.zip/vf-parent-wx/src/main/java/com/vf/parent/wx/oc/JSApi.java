package com.vf.parent.wx.oc;

import java.io.IOException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.client.ClientProtocolException;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.base.Objects;
import com.vf.parent.common.protocol.HttpUtil;
import com.vf.parent.common.util.StringUtil;
import com.vf.parent.wx.util.SignUtil;

/**
 * jsApi凭证
 *
 * @auth zhangjingxuan
 * @since 2018年3月1日下午6:06:39
 */
public class JSApi {
    
    /** Logger available */
    private final Log logger = LogFactory.getLog(getClass());
    
    /**
     * 全局jsApi票据
     */
    private String ticket;
    /**
     * 有效期    秒数
     */
    private int expires_in = 7200 - 60;
    /**
     * 全局token创建时间    秒数
     */
    private long create_time;
    /**
     * 前端调用JS是所需要的签名
     */
    private String signature;
    /**
     * 生成signature所需要的随机码
     */
    private String noncestr;
    
    /** 该票据对应的url  **/
    private String url;
    
    private String access_token;
    
    public String getUrl() {
        return url;
    }
    
    public JSApi(String access_token, String url) throws ClientProtocolException, IOException {
        this.access_token = access_token;
        this.initTicket(url);
    }
    
    /**
     * 向微信发送请求重新获取JS票据
     * 
     * <p>微信公众号正常情况下会返回:</p>
     * <code>
     * {
     *  "errcode":0,
     *  "errmsg":"ok",
     *   "ticket":"bxLdikRXVbTPdHSM05e5u5sUoXNKd8-41ZO3MhKoyN5OfkWITDGgnr2fwJ0m9E8NYzWKVZvdVtaUgWvsdshFKA",
     *   "expires_in":7200
     *  }
     * </code>
     * @auth zhangjingxuan
     * @since 2017年6月29日下午5:48:24
     * @param url           需要使用jsapi所在的url
     * @return
     * @throws IOException 
     * @throws ClientProtocolException 
     */
    private boolean initTicket(String url) throws ClientProtocolException, IOException {
        boolean flag = true;
        if (isExprexpired()) {
            StringBuilder requestUrl = new StringBuilder("https://api.weixin.qq.com/cgi-bin/ticket/getticket")
                    .append("?access_token=" + access_token)
                    .append("&type=jsapi");
            JSONObject jsonObj = JSON.parseObject(HttpUtil.sendPost(requestUrl.toString()));
            if (jsonObj.getString("errcode").equalsIgnoreCase("0")) {
                this.ticket = jsonObj.getString("ticket");              //设置js票据
                this.create_time = System.currentTimeMillis() / 1000;   //设置创建时间
                this.setSignature(ticket, url);                         //设置签名
            } else {
                if (logger.isDebugEnabled()) {
                    logger.debug("ticket of JSApi did not get to.  and response is:'" + jsonObj + "'");
                }
                flag = false;
            }
        }
        return flag;
    }
    
    /**
     * 获取对象的JSON形式
     *
     * @auth zhangjingxuan
     * @since 2018年3月5日上午10:08:40
     * @param url                   需要使用jsapi所在的url
     * @return
     * @throws ClientProtocolException
     * @throws IOException
     */
    public JSONObject getTicketData(String url) throws ClientProtocolException, IOException {
        JSONObject jsonObj = new JSONObject();
        if (this.initTicket(url)) {
            jsonObj.put("ticket", this.ticket);                     //js票据
            jsonObj.put("expires_in", this.expires_in);             //有效期    秒数
            jsonObj.put("timestamp", this.create_time);             //创建时间    秒数
            jsonObj.put("signature", this.signature);               //签名
            jsonObj.put("timeout_in", (create_time + expires_in));  //过期时间，秒数
            jsonObj.put("noncestr", noncestr);                      //随机码
            jsonObj.put("url", url);
            return jsonObj;
        }
        return null;
    }
    
    /**
     * 判断票据是否过期
     *
     * @auth zhangjingxuan
     * @return 过期返回 true,否则返回false
     * @throws IOException 
     * @throws ClientProtocolException 
     */
    private boolean isExprexpired() {
        long nowLong = System.currentTimeMillis() / 1000;
        boolean isExprexpiredFlag = nowLong >= (create_time + expires_in);
        return isExprexpiredFlag;
    }
    
    /**
     * 设置签名
     * 
     * <code>jsapi_ticket=xxxxx&noncestr=9LM4E4ZC4X43A4WD&timestamp=1498786536&url=http://www.baidu.com</code>
     * 
     * @auth zhangjingxuan
     * @since 2017年6月29日下午5:48:50
     * @param ticket
     * @param url
     */
    private void setSignature(String jsapi_ticket, String url) {
        this.noncestr = StringUtil.randomStr(16);
        this.url = url;
        this.signature = SignUtil.getSignature(jsapi_ticket, this.noncestr, String.valueOf(System.currentTimeMillis()/1000), url);
    }

    /**
     * 重写hashCode
     * 
     * <p>放入HashSet时，通过url验证重复性</p>
     * 
     * @see com.vf.parent.wx.oc.JSApiTicket
     * 
     */
    @Override
    public int hashCode() {
        return (url).hashCode();
    }

    /**
     * 重写equals
     * 
     * <p>放入HashSet时，通过url验证重复性</p>
     * 
     * @see com.vf.parent.wx.oc.JSApiTicket
     * 
     */
    @Override
    public boolean equals(Object obj) {
        if (null == obj) {
            return false;
        } 
        if (getClass() != obj.getClass()) {
            return false;
        }
        JSApi ja = (JSApi) obj;
        return Objects.equal(ja.url, url);
    }

}
