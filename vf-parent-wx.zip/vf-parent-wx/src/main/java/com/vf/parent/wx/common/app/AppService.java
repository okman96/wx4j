package com.vf.parent.wx.common.app;


import com.vf.parent.common.protocol.HttpUtils;

/**
 * 小程序登录类
 *
 * @auth zhangjingxuan
 * @since 2018年1月28日上午10:23:04
 */
public class AppService extends App {

    /* 
     * @see com.vf.parent.common.Common#getOpenid(java.lang.String)
     * {"session_key":"p49dx0CiYpUbDbMq5qMAnA==","openid":"otOol0Ytmgpie-6nRMtFVdROEG30"}
     */
    @Override
    public String getOpenid(String code) {
        String url = "https://api.weixin.qq.com/sns/jscode2session?appid=" + super.appid + "&secret=" + super.secret + "&js_code=" + code +"&grant_type=authorization_code";
        String result = HttpUtils.doGet(url);
        return result;
    }

    @Override
    public String getAppid() {
        return super.appid;
    }
    
}
