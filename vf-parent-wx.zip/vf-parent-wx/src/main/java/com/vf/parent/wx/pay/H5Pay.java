package com.vf.parent.wx.pay;

/**
 * h5支付
 *
 * @auth zhangjingxuan
 * @since 2018年3月1日下午1:37:48
 */
public class H5Pay extends AbstractPay {

    private final static String TRADE_TYPE = "MWEB";
    
    /** 
     * 统一下单
     * @see com.vf.parent.wx.pay.AbstractPay#unifiedorder(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
     */
    @Override
    public String unifiedorder(String openid, String body,
            String total_fee, String spbill_create_ip, 
            String out_trade_no, String nonce_str, 
            String wap_url, String wap_name) {
        return super.initUnifiedorderData(openid, body, total_fee, spbill_create_ip, out_trade_no, TRADE_TYPE, nonce_str, wap_url, wap_name);
    }

}
