package com.vf.parent.wx.app.oauth;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import com.vf.parent.wx.config.AppDataSource;

/**
 * 网页授权获取用户基本信息
 *
 * @auth zhangjingxuan
 * @since 2017年6月30日下午1:42:36
 */
public class Authorization extends AppDataSource {

    /**  
     * 授权类型
     * <p>不弹出授权页面，直接跳转，只能获取用户openid</p>
     */
    public static final String SCOPE_SNSAPI_BASE = "snsapi_base";
    
    /**
     * 授权类型
     * <p>弹出授权页面，可通过openid拿到昵称、性别、所在地。并且， 即使在未关注的情况下，只要用户授权，也能获取其信息</p>
     */
    public static final String SCOPE_SNSAPI_USERINFO = "snsapi_userinfo";
    
    
	/**
     * 默认授权请求URL
     */
    private String authorize_url = "https://open.weixin.qq.com/connect/oauth2/authorize";
	
    /**
     * 重定向该地址（微信授权验证地址）
     * <p>1.可获取验证码code</p>
     * <p>2.通过code可以获取网页授权access_token</p>
     *
     * @auth zhangjingxuan
     * @since 2018年1月18日上午11:39:25
     * @param redirect
     *                  再次重定向的地址
     * @param scope
     *                  授权类型：静默授权（SCOPE_SNSAPI_BASE）、非静默授权（SCOPE_SNSAPI_USERINFO）
     * @param state
     *                  可为null或""
     *                  重定向后会带上state参数，开发者可以填写a-zA-Z0-9的参数值，最多128字节
     * @return
     * @throws UnsupportedEncodingException
     */
    public String redirectForAuth(String redirect, String scope, String state) throws UnsupportedEncodingException {
        StringBuffer redirectUrl = new StringBuffer("https://open.weixin.qq.com/connect/oauth2/authorize")
                     .append("?appid=")
                     .append(super.appid)
                     .append("&redirect_uri=")
                     .append(URLEncoder.encode(redirect, "UTF-8"))
                     .append("&response_type=code&scope=")
                     .append(scope)
                     .append("&state=")
                     .append(state)
                     .append("#wechat_redirect");
        return redirectUrl.toString();
    }
    
}
