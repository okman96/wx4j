package com.vf.parent.wx.common;

/**
 * 小程序基础数据
 *
 * @auth zhangjingxuan
 * @since 2018年1月28日上午10:25:04
 */
public interface Pay extends Common {

    
}
