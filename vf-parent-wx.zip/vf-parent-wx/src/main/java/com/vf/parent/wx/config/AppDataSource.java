package com.vf.parent.wx.config;

import org.apache.commons.lang3.StringUtils;

/**
 * 微信数据配置
 * 
 * <p>适用范围：微信小程序、公众号等</p>
 *
 * @auth zhangjingxuan
 * @since 2018年1月17日下午4:33:32
 */
public class AppDataSource {

    /**
     * 微信程序唯一标识，需要bean注入后使用
     */
    protected String appid = null;
    
    /**
     * 微信程序秘钥，需要bean注入后使用
     */
    protected String appsecret = null;
    
    /**
     * 平台获取access_token请求地址 
     */
    protected String accessTokenUrl = null;
    
    public AppDataSource() {
    }
    
    /**
     * 构造函数
     * 通过aop构造方式注入
     * 为appid、appsecret、accessTokenUrl进行赋值
     */
    public AppDataSource(String appid, String appsecret) {
        this.appid = appid;
        this.appsecret = appsecret;
        this.setAccessTokenUrl();
    }
    
    public synchronized void setAppid(String appid) {
        if (StringUtils.isNotEmpty(appid)) {
            this.appid = appid;
        } else {
            System.err.println("------ appid can't be empty  ------");
        }
    }
    
    public synchronized String getAppid() {
        return this.appid;
    }
    
    public synchronized void setAppsecret(String appsecret) {
        this.setAccessTokenUrl();
        if (StringUtils.isNotEmpty(appsecret)) {
            this.appsecret = appsecret;
        } else {
            System.err.println("------ appsecret can't be empty  ------");
        }
    }
    
    public synchronized String getAppsecret() {
        return this.appsecret;
    }

    public String getAccessTokenUrl() {
        return accessTokenUrl;
    }

    public void setAccessTokenUrl(String accessTokenUrl) {
        this.accessTokenUrl = accessTokenUrl;
    }
    
    /**
     * 为accessTokenUrl赋值
     * 
     * @see this.appsecret
     * @see this.appid
     * @auth zhangjingxuan
     * @since 2018年1月18日上午11:07:19
     */
    public void setAccessTokenUrl() {
        StringBuffer buffer = new StringBuffer();
        buffer.append("https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=")
            .append(this.appid)
            .append("&secret=")
            .append(this.appsecret);
        this.accessTokenUrl = buffer.toString();
    }
    
}
