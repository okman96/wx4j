package com.vf.parent.wx.config;

/**
 * 微信数据配置
 *
 * <p>适用范围：支付场景</p>
 *
 * @auth zhangjingxuan
 * @since 2018年1月17日下午4:39:41
 */
public class PayDataSource {

    /**
     * 支付唯一标识（商户号），需要bean注入后使用
     * 商户申请微信支付后，由微信支付分配的商户收款账号。
     */
    protected String mchid = null;
    
    /**
     * API秘钥，需要bean注入后使用
     * 交易过程生成签名的密钥，仅保留在商户系统和微信支付后台，
     * 不会在网络中传播。商户妥善保管该Key，切勿在网络中传输，
     * 不能在其他客户端中存储，保证key不会被泄漏。
     * 商户可根据邮件提示登录微信商户平台进行设置。也可按一下路径设置：
     * 微信商户平台(pay.weixin.qq.com)-->账户设置-->API安全-->密钥设置
     */
    protected String apiid = null;
    
    /**
     * 支付完成回调地址，需要bean注入后使用
     */
    protected String notifyurl = null;
    
}
