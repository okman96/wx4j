package com.vf.parent.wx.common;

public interface Common {
    
    /**
     * 获取appid
     *
     * @auth zhangjingxuan
     * @since 2018年2月1日上午11:14:02
     * @return
     */
    String getAppid();
    
    /**
     * 设置appid
     *
     * @auth zhangjingxuan
     * @since 2018年3月1日下午2:18:07
     * @param appid
     * @return
     */
    void setAppid(String appid);
}
