package com.vf.parent.wx.oc;

import javax.annotation.Resource;

import com.alibaba.fastjson.JSONObject;
import com.vf.parent.common.protocol.HttpUtils;

/**
 * 微信客服接口
 *
 * @auth zhangjingxuan
 * @since 2018年3月7日下午4:29:07
 */
public class Message  {

    @Resource(name = "oAuthToken")
    private OAuthToken oAuthToken;
    
    /**
     * 推送微信消息
     *
     * @auth zhangjingxuan
     * @since 2018年3月7日下午4:35:59
     * @param openId
     * @param message
     * @return
     * @throws Exception
     */
    public String send(String openId, String message) throws Exception {
        StringBuilder requestUrl = new StringBuilder("https://api.weixin.qq.com/cgi-bin/message/custom/send")
                .append("?access_token=" + oAuthToken.getAccess_token());
        JSONObject messageJson = new JSONObject();
        messageJson.put("touser", openId);
        messageJson.put("msgtype", "text");
        JSONObject textJson = new JSONObject();
        textJson.put("content", new String(message.getBytes("utf-8")));
        messageJson.put("text", textJson);
        return HttpUtils.doPost(requestUrl.toString(), messageJson, HttpUtils.APPLICATION_JSON);
    }
    
    public OAuthToken getOAuthToken() {
        return oAuthToken;
    }

    public void setOAuthToken(OAuthToken oAuthToken) {
        this.oAuthToken = oAuthToken;
    }
    
}
