package com.vf.parent.wx.oc;

import org.apache.commons.lang3.StringUtils;

import com.vf.parent.wx.common.Common;

/**
 * 公众号抽象类
 *
 * @auth zhangjingxuan
 * @since 2018年3月1日下午5:13:40
 */
public abstract class AbstractOC implements Common {

    /**
     * 微信程序唯一标识，需要bean注入后使用
     */
    protected String appid = null;
    
    /**
     * 微信程序秘钥，需要bean注入后使用
     */
    protected String appsecret = null;
    
    /**
     * 获取access_token
     *
     * @auth zhangjingxuan
     * @since 2018年3月5日下午4:55:25
     * @return
     * @throws Exception
     */
    protected abstract String getAccess_token() throws Exception;
    
    /** 
     * 设置appid
     * @see com.vf.parent.wx.common.Common#setAppid(java.lang.String)
     */
    @Override
    public synchronized void setAppid(String appid) {
        if (StringUtils.isNotEmpty(appid)) {
            this.appid = appid;
        } else {
            System.err.println("------ appid can't be empty  ------");
        }
    }
    
    /**
     *  获取appid
     *  @see com.vf.parent.wx.common.Common#getAppid(java.lang.String)
     */
    @Override
    public String getAppid() {
        return this.appid;
    }
    
    /** 
     * 设置appsecret
     */
    public synchronized void setAppsecret(String appsecret) {
        if (StringUtils.isNotEmpty(appsecret)) {
            this.appsecret = appsecret;
        } else {
            System.err.println("------ appsecret can't be empty  ------");
        }
    }
    
    /**
     *  获取appsecret
     */
    public String getAppsecret() {
        return this.appsecret;
    }
    
}
