package com.vf.parent.wx.pay;

import java.util.HashMap;
import java.util.Map;

import org.dom4j.DocumentException;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.vf.parent.common.protocol.HttpUtil;
import com.vf.parent.common.util.SecurityUtil;
import com.vf.parent.common.util.StringUtil;
import com.vf.parent.wx.util.SignUtil;

/**
 * 支付抽象类
 *
 * @auth zhangjingxuan
 * @since 2018年3月1日下午3:01:54
 */
public abstract class AbstractPay implements CommonPay {

    protected String appid = null;

    protected String mchid = null;
    
    protected String apiid = null;
    
    protected String notifyurl = null;

    public String getMchid() {
        return mchid;
    }
    
    public void setMchid(String mchid) {
        this.mchid = mchid;
    }
    
    public String getApiid() {
        return apiid;
    }

    public void setApiid(String apiid) {
        this.apiid = apiid;
    }

    public String getNotifyurl() {
        return notifyurl;
    }

    public void setNotifyurl(String notifyurl) {
        this.notifyurl = notifyurl;
    }

    @Override
    public String getAppid() {
        return appid;
    }
    
    @Override
    public void setAppid(String appid) {
        this.appid = appid;
    }
    
    /**
     * 初始化统一下单的请求体
     *
     * @auth zhangjingxuan
     * @since 2018年3月1日下午2:51:24
     * @param openid
     * @param body
     * @param total_fee
     * @param spbill_create_ip
     * @param out_trade_no
     * @param trade_type
     * @param nonce_str
     * @param wap_url
     * @param wap_name
     * @return
     * @throws DocumentException
     */
    protected String initUnifiedorderData(String openid, String body, String total_fee, String spbill_create_ip,
            String out_trade_no, String trade_type, String nonce_str, String wap_url, String wap_name) {
        JSONObject json = new JSONObject(true);
        json.put("appid", apiid);
        json.put("body", body);
        json.put("mch_id", mchid);
        json.put("nonce_str", nonce_str);
        json.put("notify_url", notifyurl);
        json.put("openid", openid);
        json.put("out_trade_no", out_trade_no);
        json.put("spbill_create_ip", spbill_create_ip);
        json.put("total_fee", total_fee);
        json.put("trade_type", trade_type);
        //h5支付所需要
        if (trade_type.equals("MWEB")) {
            json.put("scene_info", "{\"h5_info\": {\"type\":\"Wap\",\"wap_url\": \"" + wap_url + "\",\"wap_name\": \"" + wap_name + "\"}}");
        }
        
        StringBuilder builder = new StringBuilder();
        for (Map.Entry<String, Object> entry : json.entrySet()) {
            builder.append(entry.getKey());
            builder.append("=");
            builder.append(entry.getValue());
            builder.append("&");
        }
        builder.append("key=" + apiid);
        String stringSignTemp = builder.toString();
        String sign = SecurityUtil.MD5(stringSignTemp).toUpperCase();
        String result = send(appid, body, mchid, nonce_str, notifyurl, openid, out_trade_no, spbill_create_ip, total_fee, trade_type, sign);
        return result;
    }
    
    /**
     * 支付
     * @see com.vf.parent.wx.pay.CommonPay#pay(java.lang.String, java.lang.String, java.lang.String)
     */
    @Override
    public String pay(String appid, String prepayid, String apiid) {
        Map<String, String> paySignMap = new HashMap<String, String>();
        String timeStamp = String.valueOf(System.currentTimeMillis() / 1000);
        String nonceStr = StringUtil.randomStr(16);
        //生成订单详情扩展字符串
        String packages = "prepay_id=" + prepayid;
        paySignMap.put("appId", appid);
        paySignMap.put("timeStamp", timeStamp);
        paySignMap.put("nonceStr", nonceStr);
        paySignMap.put("package", packages);
        paySignMap.put("signType", "MD5");
        //生成支付签名
        String paySign = SignUtil.getSign(paySignMap, apiid);
        paySignMap.put("appid", appid);
        paySignMap.put("paySign", paySign);
        return ((JSONObject) JSON.toJSON(paySignMap)).toJSONString();
    }
    
    /**
     * 发送统一下单接口
     *
     * @auth zhangjingxuan
     * @createtime 2017年6月28日下午3:32:48
     * @return
     */
    private static String send(String appid, String body, String mch_id, String nonce_str, String notify_url, String openid, String out_trade_no, String spbill_create_ip, String total_fee, String trade_type, String sign) {
        String xml = toXML(appid, body, mch_id, nonce_str, notify_url, openid, out_trade_no, spbill_create_ip, total_fee, trade_type, sign);
        String result = HttpUtil.sendByXML("https://api.mch.weixin.qq.com/pay/unifiedorder", "POST", xml);
        return result;
    }
    
    /**
     * 生成xml请求内容
     *
     * @auth zhangjingxuan
     * @createtime 2017年6月28日下午3:35:05
     * @return
     */
    private static String toXML(String appid, String body, String mch_id, String nonce_str, String notify_url, String openid, String out_trade_no, String spbill_create_ip, String total_fee, String trade_type, String sign) {
        StringBuilder sb = new StringBuilder();
        sb.append("<xml>");
        sb.append("<appid><![CDATA[").append(appid).append("]]></appid>");
        sb.append("<body><![CDATA[").append(body).append("]]></body>");
        sb.append("<mch_id><![CDATA[").append(mch_id).append("]]></mch_id>");
        sb.append("<nonce_str><![CDATA[").append(nonce_str).append("]]></nonce_str>");
        sb.append("<notify_url><![CDATA[").append(notify_url).append("]]></notify_url>");
        sb.append("<openid><![CDATA[").append(openid).append("]]></openid>");
        sb.append("<out_trade_no><![CDATA[").append(out_trade_no).append("]]></out_trade_no>");
        sb.append("<spbill_create_ip><![CDATA[").append(spbill_create_ip).append("]]></spbill_create_ip>");
        sb.append("<total_fee><![CDATA[").append(total_fee).append("]]></total_fee>");
        sb.append("<trade_type><![CDATA[").append(trade_type).append("]]></trade_type>");
        sb.append("<sign><![CDATA[").append(sign).append("]]></sign>");
        sb.append("</xml>");
        return sb.toString();
    }
    
}
