package com.vf.parent.wx.common.app;

import com.vf.parent.wx.common.Program;

/**
 * 小程序基础数据
 *
 * @auth zhangjingxuan
 * @since 2018年1月28日上午10:25:04
 */
public abstract class App implements Program {

    /**
     * 小程序唯一标识
     */
    protected String appid;
    
    /**
     * 小程序的 app secret
     */
    protected String secret;

    public String getAppid() {
        return appid;
    }

    public void setAppid(String appid) {
        this.appid = appid;
    }

    public String getSecret() {
        return secret;
    }

    public void setSecret(String secret) {
        this.secret = secret;
    }
    
}