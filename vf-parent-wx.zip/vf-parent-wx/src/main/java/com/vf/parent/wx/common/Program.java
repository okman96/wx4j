package com.vf.parent.wx.common;

/**
 * 小程序基础数据
 *
 * @auth zhangjingxuan
 * @since 2018年1月28日上午10:25:04
 */
public interface Program {

    /**
     * 获取用户唯一标识
     *
     * @auth zhangjingxuan
     * @since 2018年1月28日上午10:32:54
     * @param code
     *              客户端登录请求码
     * @return
     */
    String getOpenid(String code);
    
    /**
     * 获取小程序唯一标识
     *
     * @auth zhangjingxuan
     * @since 2018年2月1日上午11:14:02
     * @return
     */
    String getAppid();
    
}
