package com.vf.parent.wx.oc;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.vf.parent.common.protocol.HttpUtils;

/**
 * 公众号自定义菜单
 *
 * @auth zhangjingxuan
 * @since 2018年3月8日下午4:03:15
 */
public class Menu {

    /** Logger available */
    private final Log logger = LogFactory.getLog(getClass());
    
    @Resource(name = "oAuthToken")
    public OAuthToken oAuthToken;
    
private volatile static Menu instance = null;
    
    static {
    }
    
    public static Menu getInstance() {  
        if (instance == null) {  
            synchronized (JSApiTicket.class) {  
                if (instance == null) {  
                    instance = new Menu();  
                }  
            }  
        }  
        return instance;  
    }
    
    private Menu() {
    }
    
    /**
     * 创建自定义菜单
     *
     * @auth zhangjingxuan
     * @since 2018年3月8日下午4:12:00
     * @param body
     * @return
     * @throws Exception 
     */
    public String create(JSONObject menuBody) throws Exception {
        StringBuilder requestUrl = new StringBuilder("https://api.weixin.qq.com/cgi-bin/menu/create")
                .append("?access_token=" + oAuthToken.getAccess_token());
        return HttpUtils.doPost(requestUrl.toString(), menuBody, "application/json;charset=utf-8");
    }
    
    /**
     * 获取自定义菜单
     *
     * @auth zhangjingxuan
     * @since 2018年3月8日下午4:49:14
     * @return
     * @throws Exception 
     */
    public String get() throws Exception {
        StringBuilder requestUrl = new StringBuilder("https://api.weixin.qq.com/cgi-bin/menu/get")
                .append("?access_token=" + oAuthToken.getAccess_token());
        return HttpUtils.doGet(requestUrl.toString());
    }

    /**
     * 删除自定义菜单
     *
     * @auth zhangjingxuan
     * @since 2018年3月8日下午4:49:45
     * @return
     * @throws Exception 
     */
    public String delete() throws Exception {
        StringBuilder requestUrl = new StringBuilder("https://api.weixin.qq.com/cgi-bin/menu/delete")
                .append("?access_token=" + oAuthToken.getAccess_token());
        return HttpUtils.doGet(requestUrl.toString());
    }
    
    public OAuthToken getOAuthToken() {
        return oAuthToken;
    }

    public void setOAuthToken(OAuthToken oAuthToken) {
        this.oAuthToken = oAuthToken;
    }
    
    public static void main(String[] args) throws Exception {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("spring-config.xml");
        Menu menu = (Menu) ctx.getBean("menu");
        String str = "{\"button\":[{\"name\":\"扫码\",\"sub_button\":[{\"key\":\"rselfmenu_0_0\",\"name\":\"扫码带提示\",\"sub_button\":[],\"type\":\"scancode_waitmsg\"},{\"key\":\"rselfmenu_0_1\",\"name\":\"扫码推事件\",\"sub_button\":[],\"type\":\"scancode_push\"}]},{\"name\":\"发图\",\"sub_button\":[{\"key\":\"rselfmenu_1_0\",\"name\":\"系统拍照发图\",\"sub_button\":[],\"type\":\"pic_sysphoto\"},{\"key\":\"rselfmenu_1_1\",\"name\":\"拍照或者相册发图\",\"sub_button\":[],\"type\":\"pic_photo_or_album\"},{\"key\":\"rselfmenu_1_2\",\"name\":\"微信相册发图\",\"sub_button\":[],\"type\":\"pic_weixin\"}]},{\"key\":\"rselfmenu_2_0\",\"name\":\"发送位置\",\"type\":\"location_select\"}]}";
        JSONObject json = JSON.parseObject(str);
        System.out.println(menu.create(json));
    }
    
}
